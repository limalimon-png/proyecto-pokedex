/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Guiller
 */
public class Enumeracion {
    
    public enum Tipo{
    NORMAL, FUEGO, AGUA, PLANTA, ELECTRICO, HIELO, LUCHA, VENENO, TIERRA, VOLADOR,
    PSIQUICO, BICHO, ROCA, FANTASMA, DRAGON, SINIESTRO, ACERO,HADA
}
    
}
